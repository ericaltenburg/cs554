const moviesData = require('./movies');

module.exports = {
    movies: moviesData
};